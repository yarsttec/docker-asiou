from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from swagger_client.api.appl_api import ApplApi
from swagger_client.api.dict_api import DictApi
from swagger_client.api.xml_api import XmlApi
