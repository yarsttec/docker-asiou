# OperationResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **bool** | Результат выполнения запроса.   * &#x60;true&#x60; - успешное выполнение   * &#x60;false&#x60; - ошибка  | [optional] 
**message** | **str** | Текст ошибки (если есть) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

