# SearchResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pagination** | [**SearchResultPagination**](SearchResultPagination.md) |  | [optional] 
**columns** | [**list[Header]**](Header.md) |  | [optional] 
**results** | [**list[Row]**](Row.md) |  | [optional] 
**raw_results** | [**list[Row]**](Row.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

