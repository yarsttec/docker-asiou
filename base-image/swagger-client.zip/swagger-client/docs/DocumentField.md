# DocumentField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**slug** | **str** | Символьная метка поля | [optional] 
**value** | [**OneOfDocumentFieldValue**](OneOfDocumentFieldValue.md) | Значение поля   Возможные типы:   * &#x60;string&#x60;   * &#x60;array of string&#x60;   * &#x60;array of DocumentField object&#x60;   * &#x60;array of array of DocumentField object&#x60;  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

