# CountQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**term** | [**list[TermField]**](TermField.md) | Поисковые параметры | [optional] 
**groups** | [**list[CountGroup]**](CountGroup.md) | Описание группировки статусов для подсчета кол-ва заявлений | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

