# swagger_client.TypeinfoApi

All URIs are relative to *http://rsmev.yarcloud.ru/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**typeinfo_list**](TypeinfoApi.md#typeinfo_list) | **POST** /typeinfo/{slug}/ | Получает список данных по ВС, указанному в slug
[**typeinfo_retrieve**](TypeinfoApi.md#typeinfo_retrieve) | **GET** /typeinfo/{slug}/{snils}/ | Возвращает реестр выписок ФРИ

# **typeinfo_list**
> SearchResult typeinfo_list(slug, body=body)

Получает список данных по ВС, указанному в slug

Получает список данных по ВС с возможностью поиска, сортировки и постраничного получения результата 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basic
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.TypeinfoApi(swagger_client.ApiClient(configuration))
slug = 'slug_example' # str | Идентификатор ВС (например: initiativedistribution)
body = swagger_client.SearchQuery() # SearchQuery | Параметры фильтрации (optional)

try:
    # Получает список данных по ВС, указанному в slug
    api_response = api_instance.typeinfo_list(slug, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TypeinfoApi->typeinfo_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slug** | **str**| Идентификатор ВС (например: initiativedistribution) | 
 **body** | [**SearchQuery**](SearchQuery.md)| Параметры фильтрации | [optional] 

### Return type

[**SearchResult**](SearchResult.md)

### Authorization

[basic](../README.md#basic)

### HTTP request headers

 - **Content-Type**: */*
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **typeinfo_retrieve**
> Document typeinfo_retrieve(slug, snils)

Возвращает реестр выписок ФРИ

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint
# Configure HTTP basic authorization: basic
configuration = swagger_client.Configuration()
configuration.username = 'YOUR_USERNAME'
configuration.password = 'YOUR_PASSWORD'

# create an instance of the API class
api_instance = swagger_client.TypeinfoApi(swagger_client.ApiClient(configuration))
slug = 'slug_example' # str | Идентификатор ВС (например: initiativedistribution)
snils = 'snils_example' # str | Снилс ученика

try:
    # Возвращает реестр выписок ФРИ
    api_response = api_instance.typeinfo_retrieve(slug, snils)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TypeinfoApi->typeinfo_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **slug** | **str**| Идентификатор ВС (например: initiativedistribution) | 
 **snils** | **str**| Снилс ученика | 

### Return type

[**Document**](Document.md)

### Authorization

[basic](../README.md#basic)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

