# Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**list[DocumentField]**](DocumentField.md) | Значения полей документа | [optional] 
**columns** | [**list[DocumentColumn]**](DocumentColumn.md) | Названия полей документа | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

