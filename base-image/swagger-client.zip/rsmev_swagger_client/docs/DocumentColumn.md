# DocumentColumn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**slug** | **str** | Символьная метка поля | [optional] 
**title** | **str** | Название поля | [optional] 
**type** | **str** | Тип значения | [optional] 
**items** | [**list[DocumentColumn]**](DocumentColumn.md) | Вложенные поля | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

